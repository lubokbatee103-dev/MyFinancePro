package com.myfinancepro.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val BG = 0xFF070B18.toInt()
private const val CARD = 0xFF101A32.toInt()
private const val BLUE = 0xFF42B8FF.toInt()
private const val PURPLE = 0xFF9B7BFF.toInt()
private const val GOLD = 0xFFFFC857.toInt()
private const val WHITE = 0xFFF2F6FF.toInt()
private const val MUTED = 0xFFA9B7D0.toInt()
private const val GREEN = 0xFF53E0B0.toInt()
private const val RED = 0xFFFF718B.toInt()

class FinanceDb(context: Activity) : SQLiteOpenHelper(context, "myfinance.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, created TEXT NOT NULL)")
        db.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, target INTEGER NOT NULL, saved INTEGER NOT NULL DEFAULT 0)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addTransaction(kind: String, category: String, amount: Long, note: String) {
        val v = ContentValues().apply {
            put("kind", kind); put("category", category); put("amount", amount)
            put("note", note); put("created", SimpleDateFormat("dd MMM yyyy", Locale("id","ID")).format(Date()))
        }
        writableDatabase.insert("transactions", null, v)
    }
    fun totals(): LongArray {
        var income = 0L; var expense = 0L
        readableDatabase.rawQuery("SELECT kind, SUM(amount) FROM transactions GROUP BY kind", null).use { c ->
            while (c.moveToNext()) {
                if (c.getString(0) == "Pemasukan") income = c.getLong(1)
                else expense = c.getLong(1)
            }
        }
        return longArrayOf(income, expense)
    }
    fun goalsTotal(): Long {
        readableDatabase.rawQuery("SELECT SUM(saved) FROM goals", null).use { c -> return if (c.moveToFirst()) c.getLong(0) else 0L }
    }
    fun addGoal(name: String, target: Long) {
        val v = ContentValues().apply { put("name", name); put("target", target); put("saved", 0L) }
        writableDatabase.insert("goals", null, v)
    }
    fun deposit(goalId: Long, amount: Long) {
        writableDatabase.execSQL("UPDATE goals SET saved=saved+? WHERE id=?", arrayOf(amount, goalId))
        addTransaction("Pemasukan", "Alokasi tabungan", amount, "Setoran ke tabungan")
        // Mark the transfer separately so dashboard available balance isn't inflated.
        writableDatabase.execSQL("UPDATE transactions SET kind='Transfer' WHERE id=(SELECT MAX(id) FROM transactions)")
    }
    data class Goal(val id: Long, val name: String, val target: Long, val saved: Long)
    fun goals(): List<Goal> {
        val out = mutableListOf<Goal>()
        readableDatabase.rawQuery("SELECT id,name,target,saved FROM goals ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Goal(c.getLong(0), c.getString(1), c.getLong(2), c.getLong(3)))
        }
        return out
    }
    data class Tx(val kind: String, val category: String, val amount: Long, val note: String, val date: String)
    fun transactions(): List<Tx> {
        val out = mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT kind,category,amount,note,created FROM transactions ORDER BY id DESC LIMIT 100", null).use { c ->
            while (c.moveToNext()) out.add(Tx(c.getString(0), c.getString(1), c.getLong(2), c.getString(3) ?: "", c.getString(4)))
        }
        return out
    }
}

class MainActivity : Activity() {
    private lateinit var db: FinanceDb
    private lateinit var root: LinearLayout
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = FinanceDb(this)
        showHome()
    }

    private fun money(v: Long) = rupiah.format(v).replace("Rp", "Rp ")
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun label(text: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(3), dp(2), dp(3))
        }
    private fun button(text: String, color: Int = BLUE, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text; setTextColor(BG); textSize = 13f
            background = rounded(color, 14)
            setOnClickListener { action() }
            isAllCaps = false
        }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(CARD)
    }
    private fun space(height: Int = 10) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(20))
        }
        content.addView(label("MYFINANCE  ✦  PRO", 12f, BLUE, true))
        content.addView(label(title, 27f, WHITE, true))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(4), dp(5), dp(4), dp(8)); setBackgroundColor(0xFF0C1327.toInt())
        }
        listOf("⌂\nBeranda", "＋\nTransaksi", "◈\nTabungan", "▤\nRiwayat").forEachIndexed { i, t ->
            val b = TextView(this).apply {
                text = t; gravity = Gravity.CENTER; textSize = 12f
                setTextColor(if ((title.contains("Beranda") && i == 0) || (title.contains("Transaksi") && i == 1) || (title.contains("Tabungan") && i == 2) || (title.contains("Riwayat") && i == 3)) GOLD else MUTED)
                setPadding(dp(5), dp(7), dp(5), dp(7))
                setOnClickListener { when(i) { 0 -> showHome(); 1 -> addTransactionDialog(); 2 -> showGoals(); 3 -> showHistory() } }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        activeContent = content
    }
    private lateinit var activeContent: LinearLayout

    private fun showHome() {
        base("Dashboard")
        val totals = db.totals()
        val saved = db.goalsTotal()
        val available = totals[0] - totals[1] - saved
        activeContent.addView(space(8))
        val hero = card()
        hero.addView(label("Halo, Penjelajah Keuangan! ✦", 17f, GOLD, true))
        hero.addView(label("Maskot cyber-anime: semangat mengatur uangmu hari ini.", 13f, MUTED))
        hero.addView(space(8))
        hero.addView(label("SALDO TERSEDIA", 12f, BLUE, true))
        hero.addView(label(money(available), 29f, WHITE, true))
        activeContent.addView(hero)
        activeContent.addView(space())
        val stats = card()
        stats.addView(label("Ringkasan Keuangan", 17f, WHITE, true))
        stats.addView(label("↑ Pemasukan: ${money(totals[0])}", 15f, GREEN, true))
        stats.addView(label("↓ Pengeluaran: ${money(totals[1])}", 15f, RED, true))
        stats.addView(label("◇ Dana dalam tabungan: ${money(saved)}", 15f, GOLD, true))
        activeContent.addView(stats)
        activeContent.addView(space())
        activeContent.addView(button("＋  Catat Transaksi", BLUE) { addTransactionDialog() }, LinearLayout.LayoutParams(-1, dp(50)))
        activeContent.addView(space(7))
        activeContent.addView(button("◈  Kelola Target Tabungan", GOLD) { showGoals() }, LinearLayout.LayoutParams(-1, dp(50)))
        activeContent.addView(space())
        activeContent.addView(label("MASKOT HARI INI", 12f, PURPLE, true))
        val mascot = card()
        mascot.addView(label("✦  CYBER MIKO  ✦", 20f, BLUE, true))
        mascot.addView(label("「Sedikit demi sedikit, tujuan besar bisa tercapai!」", 14f, WHITE))
        mascot.addView(label("Tip: catat transaksi segera agar laporanmu akurat.", 12f, MUTED))
        activeContent.addView(mascot)
    }

    private fun addTransactionDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val kind = Spinner(this)
        kind.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Pemasukan", "Pengeluaran"))
        val category = EditText(this).apply { hint = "Kategori (mis. Uang saku, Makanan)"; setSingleLine() }
        val amount = EditText(this).apply { hint = "Jumlah rupiah"; inputType = InputType.TYPE_CLASS_NUMBER }
        val note = EditText(this).apply { hint = "Catatan (opsional)"; setSingleLine() }
        box.addView(label("Jenis transaksi", 13f, MUTED)); box.addView(kind)
        box.addView(category); box.addView(amount); box.addView(note)
        AlertDialog.Builder(this).setTitle("Catat Transaksi")
            .setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val n = amount.text.toString().toLongOrNull()
                if (n == null || n <= 0 || category.text.toString().isBlank()) {
                    toast("Isi kategori dan jumlah yang valid.")
                } else {
                    db.addTransaction(kind.selectedItem.toString(), category.text.toString().trim(), n, note.text.toString().trim())
                    toast("Transaksi disimpan."); showHome()
                }
            }.show()
    }

    private fun showGoals() {
        base("Target Tabungan")
        activeContent.addView(label("Buat tujuan, pantau progres, dan kumpulkan dana sedikit demi sedikit.", 14f, MUTED))
        activeContent.addView(space())
        activeContent.addView(button("＋  Buat Target Tabungan", GOLD) { addGoalDialog() }, LinearLayout.LayoutParams(-1, dp(50)))
        activeContent.addView(space())
        val goals = db.goals()
        if (goals.isEmpty()) activeContent.addView(label("Belum ada target. Buat target pertamamu, misalnya Laptop Baru.", 14f, MUTED))
        goals.forEach { g ->
            val c = card()
            c.addView(label(g.name, 18f, WHITE, true))
            c.addView(label("${money(g.saved)} dari ${money(g.target)}", 14f, GOLD, true))
            val progress = if (g.target > 0) ((g.saved * 100 / g.target).coerceIn(0, 100)).toInt() else 0
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; this.progress = progress; progressTintList = android.content.res.ColorStateList.valueOf(BLUE)
            }
            c.addView(bar, LinearLayout.LayoutParams(-1, dp(8)))
            c.addView(label("$progress% tercapai", 12f, MUTED))
            c.addView(space(5))
            c.addView(button("＋  Tambah Dana", BLUE) { depositDialog(g.id, g.name) }, LinearLayout.LayoutParams(-1, dp(46)))
            activeContent.addView(c); activeContent.addView(space())
        }
    }

    private fun addGoalDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Nama tujuan (mis. Laptop Baru)"; setSingleLine() }
        val target = EditText(this).apply { hint = "Target rupiah"; inputType = InputType.TYPE_CLASS_NUMBER }
        box.addView(name); box.addView(target)
        AlertDialog.Builder(this).setTitle("Buat Target Tabungan").setView(box)
            .setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
                val n = target.text.toString().toLongOrNull()
                if (name.text.toString().isBlank() || n == null || n <= 0) toast("Isi nama dan target yang valid.")
                else { db.addGoal(name.text.toString().trim(), n); showGoals() }
            }.show()
    }

    private fun depositDialog(id: Long, name: String) {
        val input = EditText(this).apply { hint = "Jumlah setoran rupiah"; inputType = InputType.TYPE_CLASS_NUMBER }
        AlertDialog.Builder(this).setTitle("Tambah dana: $name").setView(input)
            .setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
                val amount = input.text.toString().toLongOrNull()
                if (amount == null || amount <= 0) toast("Masukkan jumlah yang valid.")
                else {
                    val totals = db.totals()
                    val available = totals[0] - totals[1] - db.goalsTotal()
                    if (amount > available) toast("Saldo tersedia tidak cukup. Catat pemasukan terlebih dahulu.")
                    else { db.deposit(id, amount); toast("Setoran ditambahkan."); showGoals() }
                }
            }.show()
    }

    private fun showHistory() {
        base("Riwayat Transaksi")
        activeContent.addView(label("100 transaksi terbaru akan ditampilkan di sini.", 13f, MUTED))
        activeContent.addView(space())
        val items = db.transactions()
        if (items.isEmpty()) activeContent.addView(label("Belum ada transaksi. Tekan tombol Transaksi untuk mulai mencatat.", 14f, MUTED))
        items.forEach { tx ->
            val c = card()
            val color = when(tx.kind) { "Pemasukan" -> GREEN; "Pengeluaran" -> RED; else -> BLUE }
            c.addView(label("${tx.kind} • ${tx.category}", 15f, color, true))
            c.addView(label(money(tx.amount), 18f, WHITE, true))
            c.addView(label("${tx.date}${if (tx.note.isNotBlank()) "  ·  ${tx.note}" else ""}", 12f, MUTED))
            activeContent.addView(c); activeContent.addView(space(7))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
