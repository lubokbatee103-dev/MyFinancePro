# MyFinance Pro — Anime Cyberpunk Edition

Proyek Android sederhana untuk pencatatan keuangan pribadi, tabungan multi-tujuan, dan maskot anime cyberpunk.

## Yang tersedia
- Dashboard saldo, pemasukan, pengeluaran, dan total tabungan.
- Catat pemasukan/pengeluaran.
- Buat beberapa target tabungan dan tambah dana ke tujuan.
- Riwayat transaksi.
- Data disimpan lokal memakai SQLite; tidak membutuhkan internet setelah aplikasi terpasang.
- Tanpa PIN/kata sandi sesuai pilihan.

## Cara membangun APK
Proyek ini menggunakan Android Gradle Plugin dan Kotlin. Build APK membutuhkan Android SDK dan Gradle, biasanya lewat Android Studio di komputer atau lingkungan build Android yang kompatibel.
1. Buka folder proyek ini di Android Studio/IDE Android yang mendukung proyek Gradle.
2. Tunggu Gradle menyelesaikan sinkronisasi.
3. Build > Build APK(s).
4. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: Proyek belum dibangun atau diuji di lingkungan Android dalam sesi ini. Versi plugin/Gradle dapat perlu disesuaikan dengan Android SDK yang terpasang.
